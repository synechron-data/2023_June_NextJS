import Link from "next/link";
import Counter from "./components/counter";

export default function Home() {
  return (
    <>
      <h1>Welcome to Technizer India App</h1>
      <Link href="/home">Home</Link>
      <hr />
      <Counter />
    </>
  )
}
