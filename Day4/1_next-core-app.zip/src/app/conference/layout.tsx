import React from 'react';

export default function ConferenceLayout({ children }: { children: React.ReactNode }) { 
    return (
        <>
            <section>{children}</section>
        </>
    );
}