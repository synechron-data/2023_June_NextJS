'use client'

// CSR: Client Side Rendering
// import styles from '../../conference.module.css';

// import React, { useEffect } from 'react';
// import { Speaker } from '../../models/speaker';

// const SpeakerInfo = ({ id }: { id: string }) => {
//     const [speaker, setSpeaker] = React.useState({} as Speaker);

//     // useEffect(() => {
//     //     fetch(`http://localhost:8001/speakers/${id}`)
//     //         .then(response => response.json())
//     //         .then(data => setSpeaker(data))
//     //         .catch(eMsg => console.error(eMsg));
//     // }, []);

//     useEffect(() => {
//         (async () => {
//             try {
//                 const response = await fetch(`http://localhost:8001/speakers/${id}`);
//                 const data = await response.json();
//                 setSpeaker(data);
//             } catch (err) {
//                 console.error(err);
//             }
//         })()
//     }, []);

//     return (
//         <div className={styles.infoContainer}>
//             {
//                 speaker ? <div>
//                     <h3 className={styles.titleText}>{speaker.name}</h3>
//                     <h5 className={styles.descText}>About: {speaker.bio}</h5>
//                     {speaker.sessions &&
//                         speaker.sessions.map(({ name, id }) => (
//                             <div key={id}>
//                                 <h5 className={styles.descText}>Session: {name}</h5>
//                             </div>
//                         ))}
//                 </div> : <h3 className={styles.titleText}>No Details for the Speaker Found</h3>
//             }
//         </div>
//     );
// };

// export default SpeakerInfo;

// -------------------------------------------------- use from react

import styles from '../../conference.module.css';

import React, { use } from 'react';
import { Speaker } from '../../models/speaker';

async function getSpeaker(id: string) {
    try {
        const response = await fetch(`http://localhost:8001/speakers/${id}`);
        const data = await response.json();
        return data;
    } catch (err) {
        console.error(err);
    }
}

const SpeakerInfo = ({ id }: { id: string }) => {
    const speaker:any = getSpeaker(id);

    return (
        <div className={styles.infoContainer}>
            {
                speaker ? <div>
                    <h3 className={styles.titleText}>{speaker.name}</h3>
                    <h5 className={styles.descText}>About: {speaker.bio}</h5>
                    {speaker.sessions &&
                        speaker.sessions.map(({ name, id }) => (
                            <div key={id}>
                                <h5 className={styles.descText}>Session: {name}</h5>
                            </div>
                        ))}
                </div> : <h3 className={styles.titleText}>No Details for the Speaker Found</h3>
            }
        </div>
    );
};

export default SpeakerInfo;