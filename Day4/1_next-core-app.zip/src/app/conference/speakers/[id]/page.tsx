import Link from "next/link";
import styles from '../../conference.module.css';
import SpeakerInfo from "../components/speaker-info";

export default function Page({ params }: { params: { id: string } }) {
    console.log(params);
    return (
        <>
            <Link href="/conference/speakers">Back to Speakers</Link>
            <SpeakerInfo id={params.id} />
        </>
    );
}