import { Speaker } from "../models/speaker";
import styles from "../conference.module.css";
import Link from 'next/link';

// // Static data Fetching (SSG)
// async function fetchSpeakers() {
//     // We can access Database
//     // We can access Data from FileSystem
//     // We can access API
//     const response = await fetch('http://localhost:8001/speakers');
//     const data = await response.json() as Array<Speaker>;
//     return data;
// }

// Static data Fetching with revalidate (ISR)
async function fetchSpeakers() {
    // We can access Database
    // We can access Data from FileSystem
    // We can access API
    const response = await fetch(
        'http://localhost:8001/speakers',
        {
            next: {
                revalidate: 10
            }
        }
    );
    
    const data = await response.json() as Array<Speaker>;
    return data;
}

export default async function Page() {
    const speakers = await fetchSpeakers();

    return (
        <div className={styles.parentContainer}>
            <div className="self-start whitespace-nowrap rounded-lg bg-gray-700 px-3 py-1 text-sm font-medium tabular-nums text-gray-100">
                Last Rendered: {new Date().toLocaleTimeString()}
            </div>
            <h1>Welcome to Technizer India Speakers</h1>
            {
                speakers.map(({ id, name, bio }) => (
                    <div key={id} className={styles.infoContainer}>
                        <Link
                            className={styles.bgLinks}
                            href={`/conference/speakers/${id}`}
                            prefetch={false}
                        >
                            <h3 className={styles.titleText}>{name}</h3>
                        </Link>
                        <h5 className={styles.descText}>{bio}</h5>
                    </div>
                ))
            }
        </div>
    )
}