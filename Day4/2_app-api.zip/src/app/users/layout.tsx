import 'bootstrap/dist/css/bootstrap.min.css';

export default function UsersLayout({ children }: { children: React.ReactNode }) {
    return (
        <section className="container">{children}</section>
    )
}
