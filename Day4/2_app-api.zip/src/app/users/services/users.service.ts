import { fetchWrapper } from "@/lib/fetch-wrapper";

const baseUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/users`;

function getAll() {
    return fetchWrapper.get(baseUrl);
}

function getById(id: string) {
    return fetchWrapper.get(`${baseUrl}/${id}`);
}

function create(params: any) {
    return fetchWrapper.post(baseUrl, params);
}

function update(id: string, params: any) {
    return fetchWrapper.put(`${baseUrl}/${id}`, params);
}

function _delete(id: number | undefined) {
    return fetchWrapper.delete(`${baseUrl}/${id}`);
}

export const usersService = {
    getAll,
    getById,
    create,
    update,
    delete: _delete
}