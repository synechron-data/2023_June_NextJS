import { Metadata } from "next"
import { AddEdit } from "../components/add-edit.component"

export const metadata: Metadata = {
    title: 'Add User',
    description: 'Add New User Page',
}

export default function AddUserPage() {
    return (
        <div className='text-center mt-5'>
            <AddEdit />
        </div>
    )
}