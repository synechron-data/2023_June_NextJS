export default function Home() {
  return (
    <>
      <div className='w-full bg-black'>
        <main className='flex justify-center items-center m-auto h-screen flex-col'>
          <div className='text-8xl text-white'>
            Welcome to <a href='https://nextjs.org'>Next.js 13!</a>
          </div>
          <div className='text-4xl my-10 text-white'>
            This is a Tailwind Example
          </div>
        </main>
      </div>
    </>
  )
}
