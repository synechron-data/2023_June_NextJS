export default function Page() {
    return (
        <>
            <h1>Welcome to Blog</h1>
        </>
    )
}