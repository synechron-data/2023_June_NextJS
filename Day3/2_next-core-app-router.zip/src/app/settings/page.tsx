export default function Page() {
    return (
        <>
            <h1>Welcome to Settings Page</h1>
        </>
    )
}