import React from 'react';

export default function ConferenceLayout({ children }: { children: React.ReactNode }) { 
    return (
        <>
            <section id="cLayout">{children}</section>
        </>
    );
}