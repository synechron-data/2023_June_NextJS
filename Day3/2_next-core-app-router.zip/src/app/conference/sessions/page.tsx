export default function Page() {
    return (
        <>
            <h1>Welcome to Technizer India Sessions</h1>
        </>
    )
}