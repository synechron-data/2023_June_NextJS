export default function Page() {
    return (
        <>
            <h1>Charlotte Eriksson</h1>
            <p>
                You can start anew at any given moment. <br />Life is just the passage of time and it’s up to you to pass it as you please.
            </p>
        </>
    )
}