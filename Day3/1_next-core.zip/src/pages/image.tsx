import Head from 'next/head'
import Image from 'next/image'

import inkwater from '../../public/ink-water.png';
import myLoader from './myLoader';

export default function ImagePage() {
    console.log("Rendering Image Page");

    return (
        <>
            <Head>
                <title>Image Page</title>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="page-description" content="Image Page" />
            </Head>
            <main>
                <h1 className='text-primary text-center mt-5'>Welcome to Image Page!</h1>
                <div className='text-center mt-5'>
                    {/* <img src={inkwater.src} alt="Picture of the Ink in Water" /> */}

                    {/* <Image src={inkwater} alt="Picture of the Ink in Water" width={1000} height={500} priority={true} /> */}

                    <Image
                        loader={myLoader}
                        src="photo-1558494949-ef010cbdcc31"
                        alt="Picture of the Server"
                        width={1000}
                        height={500}
                        priority={true} />
                </div>
            </main>
        </>
    )
}