import Head from 'next/head'
import { getProducts } from '../../data';
import Products from '../../components/products/products';

export default function ProductsPage({ products }: { products: any[] }) {
    return (
        <>
            <Head>
                <title>Products Page</title>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="page-description" content="Products Page" />
            </Head>
            <main>
                <h1 className='text-primary text-center mt-5'>
                    Welcome to Products Page!
                </h1>

                <div className="text-center mt-5">
                    <section>
                        <div className="row">
                            <Products products={products} />
                        </div>
                    </section>
                </div>
            </main>
        </>
    )
}

// SSG
// export async function getStaticProps() {
//     const products = await getProducts();
//     return {
//         props: {
//             products
//         }
//     }
// }

// SSR
// export async function getServerSideProps() {
//     const products = await getProducts();
//     return {
//         props: {
//             products
//         }
//     }
// }

// ----------------------------- API Call

// SSG
// export async function getStaticProps() {
//     const res = await fetch('http://localhost:8001/products');
//     const products = await res.json();

//     return {
//         props: {
//             products
//         }
//     }
// }

// SSR
// export async function getServerSideProps() {
//     const res = await fetch('http://localhost:8001/products');
//     const products = await res.json();

//     return {
//         props: {
//             products
//         }
//     }
// }

// ISR
// export async function getStaticProps() {
//     const res = await fetch('http://localhost:8001/products');
//     const products = await res.json();

//     return {
//         props: {
//             products
//         },
//         revalidate: 10  // 10 seconds
//     }
// }

export async function getStaticProps() {
    const res = await fetch(process.env.PRODUCTS_URL || '');
    const products = await res.json();

    return {
        props: {
            products
        },
        revalidate: 10  // 10 seconds
    }
}