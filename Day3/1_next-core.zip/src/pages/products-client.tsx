import Head from 'next/head';
import React, { useEffect } from 'react';
import Products from '../../components/products/products';
import { ProductModel } from '../../models/product-model';

export default function ProductsClientPage() {
    const [products, setProducts] = React.useState<Array<ProductModel>>([]);
    const [message, setMessage] = React.useState<string>("We are sold out!");

    useEffect(() => {
        // console.log(process.env);
        fetch(process.env.NEXT_PUBLIC_PRODUCTS_URL || '')
            .then((res: Response) => res.json())
            .then((data: ProductModel[]) => {
                setProducts(data);
            }).catch((err: Error) => {
                setMessage(err.message);
            });
    }, []);

    return (
        <>
            <Head>
                <title>Products Page</title>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="page-description" content="Products Page" />
            </Head>
            <main>
                <h1 className='text-primary text-center mt-5'>
                    Welcome to Products Page!
                </h1>

                <div className="text-center mt-5">
                    {
                        products.length > 0 ? (
                            <section>
                                <div className="row">
                                    <Products products={products} />
                                </div>
                            </section>
                        ) : <h2>{message}</h2>
                    }
                </div>
            </main>
        </>
    );
}