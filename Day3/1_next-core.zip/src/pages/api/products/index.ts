import { NextApiRequest, NextApiResponse } from "next";
import { getProducts } from "../../../../data";

function handler(req: NextApiRequest, res: NextApiResponse) {
    switch (req.method) {
        case "GET":
            return getAllProducts(req, res);
        default:
            return res.status(405).json({ message: "Method not allowed" });
    }
}

async function getAllProducts(req: NextApiRequest, res: NextApiResponse) {
    try {
        const products = await getProducts();
        return res.status(200).json(products);
    } catch (err: any) {
        console.log(err);
        return res.status(500).json({ message: err.message });
    }
}

export default handler;