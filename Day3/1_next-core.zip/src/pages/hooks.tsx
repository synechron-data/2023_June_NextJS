import Head from 'next/head'
import HooksRoot from '../../components/hooks/hooks-root';

export default function Hooks() {
    console.log("Rendering Hooks Page");
    
    return (
        <>
            <Head>
                <title>Hooks Page</title>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="page-description" content="Hooks Page" />
            </Head>
            <main>
                <h1 className='text-primary text-center mt-3'>Welcome to Hooks Page!</h1>
                <div className="text-center mt-4">
                    <HooksRoot />
                </div>
            </main>
        </>
    )
}