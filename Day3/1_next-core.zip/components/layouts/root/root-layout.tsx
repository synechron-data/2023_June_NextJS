import Link from 'next/link';
import React from 'react';

const RootLayout = ({ children }: { children: React.ReactNode }) => {
    return (
        <div className='container-fluid'>
            <div className="text-center">
                <Link href="/">Index</Link>
                <span> | </span>
                <Link href="/hooks">Hooks</Link>
                <span> | </span>
                <Link href="/image">Image</Link>
                <span> | </span>
                <Link href="/font">Font</Link>
                <span> | </span>
                <Link href="/env">Env</Link>
                <span> | </span>
                <Link href="/products">Products</Link>
                <span> | </span>
                <Link href="/products-client">CSR</Link>
            </div>
            {children}
        </div>
    );
};

export default RootLayout;