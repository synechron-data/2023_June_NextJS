import React, { useState } from 'react';
import { useTasksDispatch } from './tasks-context';

let nextId = 3;

const AddTask = () => {
    const [text, setText] = useState('');
    const dispatch = useTasksDispatch();

    return (
        <div className='input-group'>
            <input className='form-control'
                placeholder="Add task"
                value={text}
                onChange={e => setText(e.target.value)}
            />
            <button
                className='btn btn-outline-primary' onClick={() => {
                    setText('');
                    dispatch({
                        type: 'added',
                        payload: { id: nextId++, text: text, done: false }
                    })
                }}>Add</button>
        </div >
    );
};

export default AddTask;