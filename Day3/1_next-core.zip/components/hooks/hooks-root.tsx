import React from 'react';
import ReducerHookDemo from './reducer-hook';
import ReducerAndContextHookDemo from './reducer-context-hook';
import CustomHookDemo from './custom-hook';
import CounterRoot from './counter-context/counter-root';
import Assignment from './assignment/assignment-root';

function hRender(no: number) {
    switch (no) {
        case 1:
            return <ReducerHookDemo />;
        case 2:
            return <ReducerAndContextHookDemo />;
        case 3:
            return <CustomHookDemo />;
        case 4:
            return <CounterRoot />;
        case 5:
            return <Assignment />;
        default:
            return <></>;
    }
}

const HooksRoot = () => {
    const [hookNo, setHookNo] = React.useState(1);

    return (
        <>
            <div className="row">
                <div className="col-3">
                    <div className="d-grid gap-2 mx-auto col-6">
                        <button className='btn btn-primary' onClick={e => { setHookNo(1); }}>Reducer Hook</button>
                        <button className='btn btn-primary' onClick={e => { setHookNo(2); }}>Context Hook</button>
                        <button className='btn btn-primary' onClick={e => { setHookNo(3); }}>Custom Hook</button>
                        <button className='btn btn-primary' onClick={e => { setHookNo(4); }}>Code Structuring</button>
                        <button className='btn btn-primary' onClick={e => { setHookNo(5); }}>Assignment</button>
                    </div>
                </div>
                <div className="col-9 card">
                    {hRender(hookNo)}
                </div>
            </div>
        </>
    );
};

export default HooksRoot;