import React, { useContext, useReducer } from 'react';

type MyType = { countState: any, countDispatch: React.Dispatch<any> };

const initialState = { count: 0 };

// const CountContext = React.createContext<MyType>({ countState: initialState, countDispatch: () => { } });
const CountContext = React.createContext({} as MyType);

const counterReducer = (state: any, action: any) => {
    switch (action.type) {
        case 'increment':
            return { count: state.count + (action.payload || 1) };
        case 'decrement':
            return { count: state.count - (action.payload || 1) };
        default:
            throw new Error('Invalid Action Executed...');
    }
}

const Counter = () => {
    const countContext = useContext(CountContext);

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <div className="text-center">
                    <h2 className="text-primary">{countContext.countState.count}</h2>
                </div>
                <button className="btn btn-primary"
                    onClick={(e) => {
                        countContext.countDispatch({ type: 'increment', payload: 2 });
                    }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary"
                    onClick={(e) => {
                        countContext.countDispatch({ type: 'decrement', payload: 2 });
                    }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </>
    );
};

const CounterSibling = () => {
    const countContext = useContext(CountContext);

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter Sibling</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <div className="text-center">
                    <h2 className="text-primary">{countContext.countState.count}</h2>
                </div>
                <button className="btn btn-primary"
                    onClick={(e) => {
                        countContext.countDispatch({ type: 'increment', payload: 5 });
                    }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-primary"
                    onClick={(e) => {
                        countContext.countDispatch({ type: 'decrement', payload: 5 });
                    }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </>
    );
};

const ReducerAndContextHookDemo = () => {
    const [count, dispatch] = useReducer(counterReducer, initialState);

    return (
        <CountContext.Provider value={{ countState: count, countDispatch: dispatch }}>
            <Counter />
            <hr />
            <CounterSibling />
        </CountContext.Provider>
    );
};

export default ReducerAndContextHookDemo;