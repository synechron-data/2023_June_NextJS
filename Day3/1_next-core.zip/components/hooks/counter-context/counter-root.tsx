import React from 'react';
import Counter from './counter';
import CounterSibling from './counter-sibling';
import { CounterProvider } from './counter-context';

const CounterRoot = () => {
    return (
        <CounterProvider>
            <Counter />
            <hr />
            <CounterSibling />
        </CounterProvider>
    );
};

export default CounterRoot;