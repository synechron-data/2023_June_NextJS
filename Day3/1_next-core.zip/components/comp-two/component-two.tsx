import React from 'react';

const ComponentTwo = () => {
    return (
        <div className='para'>
            <style jsx>{`
                .para { 
                    font-size: 15px;
                    background-color: lightblue;
                }
            `}</style>
            <p>Hello from Component Two</p>
        </div>
    );
};

export default ComponentTwo;