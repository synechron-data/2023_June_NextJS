import React from 'react';
import Image from 'next/image'
import Link from 'next/link'
import { ProductModel } from '../../models/product-model';

const Product = ({ item }: { item: ProductModel }) => {
    return (
        <div className="card" style={{ width: '300px' }}>
            <Image
                src={item.imageUrl}
                className="card-img-top"
                alt={item.name}
                width={300} height={300}
            />
            <div className="card-body">
                <h5 className="card-title">{item.name}</h5>
                <p className="card-text">{item.description}</p>
                <p className="card-text">{`Price: $${item.price}`}</p>
                <Link href={`/products/${item.id}`}>
                    See more
                </Link>
            </div>
        </div>
    );
};

export default Product;