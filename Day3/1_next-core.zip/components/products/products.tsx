import { ProductModel } from "../../models/product-model";
import Product from "./product";

export default function Products({ products }: { products: ProductModel[] }) {
    return (
        <>
            <h3 className="text-center">OUR PRODUCTS</h3>
            {
                products.map(product => (
                    <div key={product.id} className="col-md-4 pt-2 pb-2">
                        <Product item={product} />
                    </div>
                ))
            }
        </>
    );
}