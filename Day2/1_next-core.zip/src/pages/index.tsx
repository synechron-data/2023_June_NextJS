import Head from 'next/head'
import ComponentOne from '../../components/comp-one/component-one';
import ComponentTwo from '../../components/comp-two/component-two';
import ComponentThree from '../../components/comp-three/ComponentThree';

export default function Home() {
  console.log("Rendering Index Page");

  return (
    <>
      <Head>
        <title>Index Page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="page-description" content="Index Page" />
      </Head>
      <main>
        <h1 className='text-primary text-center mt-5'>Welcome to Index Page!</h1>

        <div className="text-center mt-5">
          <ComponentOne />
          <ComponentTwo />
          <ComponentThree />
        </div>
      </main>
    </>
  )
}