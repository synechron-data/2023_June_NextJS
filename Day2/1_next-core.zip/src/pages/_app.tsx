import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-icons/font/bootstrap-icons.css'
import '@/styles/globals.css'

import type { AppProps } from 'next/app'
import { useEffect } from 'react'
import RootLayout from '../../components/layouts/root/root-layout'
import { TasksProvider } from '../../components/hooks/assignment/tasks-context'

export default function App({ Component, pageProps }: AppProps) {
  useEffect(() => {
    import('bootstrap');
    import('lodash');
  }, []);

  const getLayout = (Component as any).getLayout || ((page: any) => <RootLayout> {page} </RootLayout>);

  return getLayout(
    <TasksProvider>
      <Component {...pageProps} />
    </TasksProvider>
  )
}