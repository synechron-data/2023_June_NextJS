import Head from 'next/head'
import { getProducts } from '../../data';

export default function ProductsPage({ products }: { products: any[] }) {
    return (
        <>
            <Head>
                <title>Products Page</title>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="page-description" content="Products Page" />
            </Head>
            <main>
                <h1 className='text-primary text-center mt-5'>
                    Welcome to Products Page!
                </h1>

                <div className="text-center mt-5">
                    <section>
                        <div className="row">
                            {
                                products.map((product) => (
                                    <div className="col-4" key={product.id}>
                                        <div className="card">
                                            <div className="card-header">
                                                <h5 className="card-title">{product.name}</h5>
                                            </div>
                                            <div className="card-body">
                                                <p className="card-text">{product.description}</p>
                                                <p className="card-text">{product.price}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            }
                        </div>
                    </section>
                </div>
            </main>
        </>
    )
}

// SSG
// export async function getStaticProps() {
//     const products = await getProducts();
//     return {
//         props: {
//             products
//         }
//     }
// }

// SSR
export async function getServerSideProps() {
    const products = await getProducts();
    return {
        props: {
            products
        }
    }
}