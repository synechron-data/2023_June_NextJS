import { ImageLoaderProps } from "next/image";

export default function myLoader({src, width, quality}: ImageLoaderProps) {
    return `https://images.unsplash.com/${src}?w=${width}&q=${quality || 75}`;
}