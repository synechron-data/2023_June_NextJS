import Head from 'next/head'

// console.log("GREETINGS: ", process.env.GREETINGS);

export default function EnvPage() {
    // console.log("Rendering Env Page -", process.env.GREETINGS);

    return (
        <>
            <Head>
                <title>Env Page</title>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="page-description" content="Env Page" />
            </Head>
            <main>
                <h1 className='text-primary text-center mt-5'>Welcome to Env Page!</h1>
                <h2 className='text-success'>Greetings 1: {process.env.NEXT_PUBLIC_GREETING_ONE}</h2>
                <h2 className='text-success'>Greetings 2: {process.env.NEXT_PUBLIC_GREETING_TWO}</h2>
            </main>
        </>
    )
}