import Head from 'next/head'
import { Ruda } from 'next/font/google';

const ruda = Ruda({
    weight: '400',
    subsets: ['latin'],
    display: 'swap'
})

export default function FontPage() {
    console.log("Rendering Font Page");

    return (
        <>
            <Head>
                <title>Font Page</title>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="page-description" content="Font Page" />
            </Head>
            <main className={ruda.className}>
                <h1 className='text-primary text-center mt-5'>Welcome to Font Page!</h1>
            </main>
        </>
    )
}