import React, { useContext, useReducer } from 'react';

export const counterActions = {
    increment: 'increment',
    decrement: 'decrement'
};

const counterState = { count: 0 };

export const CounterContext = React.createContext({} as any);
export const CounterDispatchContext = React.createContext({} as any);

const counterReducer = (state: any, action: any) => {
    switch (action.type) {
        case counterActions.increment:
            return { count: state.count + (action.payload || 1) };
        case counterActions.decrement:
            return { count: state.count - (action.payload || 1) };
        default:
            throw new Error("Invalid Action Executed....");
    }
}

export function CounterProvider({ children }: { children: React.ReactNode }) {
    const [counter, dispatch] = useReducer(counterReducer, counterState);

    return (
        <CounterContext.Provider value={counter}>
            <CounterDispatchContext.Provider value={dispatch}>
                {children}
            </CounterDispatchContext.Provider>
        </CounterContext.Provider>
    );
}

// Custom Hooks
export function useCounter() {
    return useContext(CounterContext);
}

export function useCounterDispatch() {
    return useContext(CounterDispatchContext);
}