import React from 'react';
import { useCounter } from './counter-context';

const CounterSibling = () => {
    const counter = useCounter();

    return (
        <>
            <div className="text-center">
                <h1 className="text-info">Counter Sibling Component</h1>
            </div>
            <div className="d-grid gap-2 mx-auto col-6 text-center">
                <h2 className='text-primary'>
                    Current Count is: {counter.count}
                </h2>
            </div>
        </>
    );
};

export default CounterSibling;