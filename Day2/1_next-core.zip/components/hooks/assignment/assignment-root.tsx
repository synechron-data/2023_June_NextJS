import React from 'react';
import AddTask from './add-task';
import TaskList from './task-list';
// import { TasksProvider } from './tasks-context';

const Assignment = () => {
    return (
        <div className="d-flex justify-content-center mt-5">
            <div className="col-6">
                <div>
                    <h2>Assignment</h2>
                    {/* <TasksProvider>
                        <AddTask />
                        <TaskList />
                    </TasksProvider> */}
                    <>
                        <AddTask />
                        <TaskList />
                    </>
                </div>
            </div>
        </div>
    );
};

export default Assignment;