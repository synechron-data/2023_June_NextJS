import React from 'react';
import styles from './ComponentThree.module.css'

const ComponentThree = () => {
    return (
        <>
          <h2 className='text-success'>Hello from Component Three</h2>  
          <h2 className={styles.card}>From Component Three</h2>  
        </>
    );
};

export default ComponentThree;