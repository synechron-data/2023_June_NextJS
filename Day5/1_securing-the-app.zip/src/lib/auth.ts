import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

export const authOptions: NextAuthOptions = {
    pages: {
        signIn: "/login",
    },
    session: {
        strategy: "jwt",
    },
    providers: [
        CredentialsProvider({
            name: "Sign In",
            credentials: {
                email: { label: "Email", type: "email", placeholder: "manish@example.com" },
                password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
                // const user = { id: "1", name: "Admin", email: "admin@abc.com" }
                // return user;

                // Code to get User from DB and verify the identity, return the user to be serialized
                if (!credentials?.email || !credentials.password) {
                    return null;
                }

                if ((credentials.email !== "manish@abc.com") || (credentials.password !== "manish")) {
                    return null;
                }

                return {
                    id: "1",
                    name: "Manish Sharma",
                    email: "manish@abc.com",
                    randomKey: "MyRandomKey"
                };
            }
        })
    ],
    callbacks: {
        session: ({ session, token }) => {
            console.log("Session Callback");
            return {
                ...session,
                user: {
                    ...session.user,
                    id: token.id,
                    randomKey: token.randomKey,
                },
            };
        },
        jwt: ({ token, user }) => {
            console.log("JWT Callback");
            if (user) {
                const u = user as unknown as any;
                return {
                    ...token,
                    id: u.id,
                    randomKey: u.randomKey,
                };
            }
            return token;
        },
    }
}