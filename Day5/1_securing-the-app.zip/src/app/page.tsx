import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth";
import UserClient from "./components/user-client.component";

export default async function Home() {
  // throw new Error("An error occurred on Home Component");
  const session = await getServerSession(authOptions);
  return (
    <>
      <div className='w-full bg-black text-white'>
        <main className='flex justify-center items-center m-auto h-screen flex-col'>
          <div className='text-8xl'>
            Welcome to <a href='https://nextjs.org'>Next.js 13!</a>
          </div>
          <div className='text-4xl my-10'>
            This is a Tailwind Example
          </div>
          <div className="flex flex-col justify-center items-center text-xl">
            <h1>Server Session</h1>
            <pre>
              {
                session
                  ? JSON.stringify(session)
                  : <p>You are not logged in!</p>
              }
            </pre>

            <UserClient />
          </div>
        </main>
      </div>
    </>
  )
}
