'use client'

import { useEffect } from 'react'

export default function Error({ error, reset }: { error: Error, reset: () => void }) {
    useEffect(() => {
        // Error Reporting
        console.error(error);
    }, [error]);

    return (
        <div className="mt-5 text-center">
            <h1 className="text-primary text-3xl font-bold">Error - Root Path</h1>
            <h2 className="text-red-500 text-2xl font-semibold">500 - Internal Server Error</h2>
            <p className="text-red-500">{error.message}</p>
            <button className="mt-4 px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600" onClick={() => reset()}>
                Try Again
            </button>
        </div>
    )
}

Error.displayName = 'Error - Root Path';