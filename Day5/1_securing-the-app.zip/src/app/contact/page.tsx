// @refresh reset
"use client"
import { cache, use } from "react";
import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";

interface User {
    id: number;
    name: string;
    email: string;
}

const getUsers = cache(() =>
    fetch("https://jsonplaceholder.typicode.com/users").then((res) => res.json())
);

export default function ContactComponent() {
    const { status } = useSession({
        required: true,
        onUnauthenticated() {
            redirect("/api/auth/signin");
        }
    });

    if (status === "loading")
        return;

    let users = use<User[]>(getUsers());

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold mb-8">User List</h1>
            {users.length === 0 ? (
                <p className="text-gray-500">Loading users...</p>
            ) : (
                <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                    {users.map((user) => (
                        <li key={user.id} className="bg-white shadow-md rounded-md p-4">
                            <div className="flex items-center mb-4">
                                <img
                                    src={`https://picsum.photos/180/180?random=${user.id}`}
                                    alt={`Random Image ${user.id}`}
                                    className="w-16 h-16 rounded-full mr-4"
                                />
                                <div>
                                    <h2 className="text-lg font-semibold">{user.name}</h2>
                                    <p className="text-gray-500">
                                        <a href={`mailto:${user.email}`}
                                            className="text-blue-500 hover:text-blue-700 underline"                                        >
                                            {user.email}
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}
