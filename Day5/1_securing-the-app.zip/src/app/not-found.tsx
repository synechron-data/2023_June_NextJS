import Link from "next/link";

export default function NotFound() {
    return (
        <div className="flex justify-center h-screen mt-8">
            <div>
                <h2 className="text-4xl text-center">404 - Page Not Found</h2>
                <p className="text-xl text-center">Could not find the requested resource</p>
                <p className="text-lg text-center">
                    View <Link href="/" className="text-blue-500 hover:text-blue-700 underline">Home</Link>
                </p>
            </div>
        </div>
    )
}