import 'bootstrap/dist/css/bootstrap.min.css';

export default function LoginLayout({ children }: { children: React.ReactNode }) {
    return (
        <section className="container">{children}</section>
    )
}
