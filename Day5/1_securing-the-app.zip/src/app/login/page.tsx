"use client"
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';

import { signIn } from "next-auth/react";
import { useSearchParams, useRouter } from 'next/navigation';

const Login = () => {
    const [loginError, setLoginError] = useState("");

    const router = useRouter();
    const searchParams = useSearchParams();
    const callbackUrl = searchParams?.get('callbackUrl') || '/';

    const validationSchema = Yup.object().shape({
        username: Yup.string().required('Username is required').email('Not a valid username'),
        password: Yup.string().required('Password is required')
    });
    const formOptions = { resolver: yupResolver(validationSchema) };

    const { register, handleSubmit, setError, formState } = useForm(formOptions);
    const { errors } = formState;

    async function onSubmit({ username, password }: { username: string, password: string }) {
        const result = await signIn('credentials', {
            email: username,
            password: password,
            redirect: false,
            callbackUrl
        });

        if (result?.error) {
            setLoginError("Invalid Email or Password");
        } else {
            router.push(callbackUrl);
        }
    };

    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-md-6 offset-md-3">
                    <div className="card">
                        <h4 className="card-header text-center bg-primary text-white">Login</h4>
                        <div className="card-body">
                            {!!loginError && <div className="alert alert-danger mb-4">{loginError}</div>}
                            <div className="text-center mb-4">
                                <img src="https://source.unsplash.com/random/400x200" alt="Login Image" className="img-fluid" />
                            </div>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <div className="mb-3">
                                    <label htmlFor="username" className="form-label">Username</label>
                                    <input type="text" {...register('username')} className={`form-control ${errors.username ? 'is-invalid' : ''}`} id="username" />
                                    <div className="invalid-feedback">{errors.username?.message}</div>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="password" className="form-label">Password</label>
                                    <input type="password" {...register('password')} className={`form-control ${errors.password ? 'is-invalid' : ''}`} id="password" />
                                    <div className="invalid-feedback">{errors.password?.message}</div>
                                </div>
                                <div className="text-center">
                                    <button disabled={formState.isSubmitting} className="btn btn-primary">
                                        {formState.isSubmitting && <span className="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>}
                                        Login
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Login;