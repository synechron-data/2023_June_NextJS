"use client"

import React from 'react';
import { useSession } from 'next-auth/react';

const UserClient = () => {
    const { data: session } = useSession();
    return (
        <>
            <h1>Client Session</h1>
            <pre>
                {
                    session
                        ? JSON.stringify(session)
                        : <p>You are not logged in!</p>
                }
            </pre>
        </>
    );
};

export default UserClient;