import { Metadata } from "next"
import { AddEdit } from "../components/add-edit.component"

export const metadata: Metadata = {
    title: 'Add User',
    description: 'Add New User Page',
}

export default function AddUserPage() {
    // throw new Error("An error occurred on Users->Add Page");

    return (
        <div className='text-center mt-5'>
            <AddEdit />
        </div>
    )
}