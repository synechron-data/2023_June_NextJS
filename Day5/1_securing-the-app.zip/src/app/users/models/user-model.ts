export interface UserModel {
    title?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    role?: string;
    password?: string;
    id?: number;
    dateCreated?: string;
    dateUpdated?: string;
    isDeleting?: boolean;
}