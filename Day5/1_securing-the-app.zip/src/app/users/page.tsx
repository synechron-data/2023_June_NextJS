import { Metadata } from "next"
import Link from "next/link"
import UsersComponent from "./components/users.component"

export const metadata: Metadata = {
    title: 'Users',
    description: 'Technizer India Users Page',
}

function ThrowException() { 
    throw new Error("An error occurred on Users Page");
}

export default function Users() {
    // ThrowException();

    return (
        <div className='text-center mt-5'>
            <h1 className="text-primary">Users Page</h1>

            <>
                <Link href="/users/add" prefetch={false}>
                    Add User
                </Link>

                <table className="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <UsersComponent />
                    </tbody>
                </table>
            </>
        </div>
    )
}
