'use client'

import { useEffect } from 'react'

export default function Error({ error, reset }: { error: Error, reset: () => void }) {
    useEffect(() => {
        // Error Reporting
        console.error(error);
    }, [error]);

    return (
        <div className='mt-5 text-center'>
            <h1 className="text-primary">Error - Users Path</h1>
            <h2 className="text-danger">500 - Internal Server Error</h2>
            <p className="text-danger">{error.message}</p>
            <button className="btn btn-warning" onClick={() => reset()}>
                Try Again
            </button>
        </div>
    )
}

Error.displayName = 'Error - Users Path';