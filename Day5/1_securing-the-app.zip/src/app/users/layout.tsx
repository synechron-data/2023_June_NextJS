import 'bootstrap/dist/css/bootstrap.min.css';

export default function UsersLayout({ children }: { children: React.ReactNode }) {
    // throw new Error("An error occurred on Users Layout");
    return (
        <section className="container">{children}</section>
    )
}
