import { Metadata } from "next"
import { AddEdit } from "../../components/add-edit.component"
import { usersRepo } from "@/lib/users-repository";

export const metadata: Metadata = {
    title: 'Edit User',
    description: 'Edit User Page',
}

function fetchUser(id: string | number) { 
    const user = usersRepo.getById(id);
    return user;
}

export default function EditUserPage({ params }: { params: { id: string } }) {
    const user = fetchUser(params.id);
    
    return (
        <div className='text-center mt-5'>
            <AddEdit user={user}/>
        </div>
    )
}