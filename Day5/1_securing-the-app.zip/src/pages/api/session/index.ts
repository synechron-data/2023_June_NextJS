import { NextApiRequest, NextApiResponse } from "next";
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    switch (req.method) {
        case 'GET':
            return getSession();
        default:
            return res.status(405).end(`Method ${req.method} Not Allowed`)
    }

    async function getSession() {
        const session = await getServerSession(req, res, authOptions);

        return res.json({
            authenticated: !!session,
            session
        });
    }
}