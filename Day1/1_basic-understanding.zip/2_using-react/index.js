// const appElement = document.getElementById('app');

// const hOneElement = document.createElement('h1');
// hOneElement.textContent = 'Hello World';
// hOneElement.className = 'orange';

// appElement.appendChild(hOneElement);

// ------------------------------
const myHOneElement = React.createElement('h1', { className: 'orange' }, 'Hello World');
ReactDOM.render(myHOneElement, document.getElementById('app'));