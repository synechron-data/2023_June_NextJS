import React from 'react';

class Hello extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: new Date().toLocaleTimeString()
        }
    }

    tick() {
        this.setState(() => {
            return ({
                data: new Date().toLocaleString()
            });
        })
    }

    componentDidMount() {
        this.interval = setInterval(() => this.tick(), 1000);
    }

    componentWillUnmount() {
        clearInterval(this.interval);
    }

    render() {
        return (
            <h1 className="orange">
                Hello World, Class - {this.state.data}
            </h1>
        );
    }
}

export { Hello };