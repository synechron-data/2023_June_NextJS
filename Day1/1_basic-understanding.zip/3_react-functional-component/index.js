// const myHOneElement = React.createElement('h1', { className: 'orange' }, 'Hello World');
// ReactDOM.render(myHOneElement, document.getElementById('app'));

// // ------------------------------
// const Hello = () => {
//     return React.createElement('h1', { className: 'orange' }, 'Hello World');
// }

// ReactDOM.render(
//     React.createElement(Hello),
//     document.getElementById('app')
// );

// ------------------------------
const Hello = (props) => {
    return React.createElement(
        'h1',
        { className: 'orange' },
        `Hello World - ${props.data}`
    );
}

ReactDOM.render(
    React.createElement(Hello, { data: new Date().toLocaleTimeString() }, null),
    document.getElementById('app')
);
