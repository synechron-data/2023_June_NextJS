// const Hello = (props) => {
//     return React.createElement(
//         'h1',
//         { className: 'orange' },
//         `Hello World - ${props.data}`
//     );
// }

// ReactDOM.render(
//     React.createElement(Hello, { data: new Date().toLocaleTimeString() }, null),
//     document.getElementById('app')
// );

// ------------------------------

class Hello extends React.Component {
    render() {
        return React.createElement(
            'h1',
            { className: 'orange' },
            `Hello World, Class - ${this.props.data}`
        );
    }
}

ReactDOM.render(
    React.createElement(Hello, { data: new Date().toLocaleTimeString() }, null),
    document.getElementById('app')
);
