class Hello extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: new Date().toLocaleTimeString()
        }
    }

    tick() {
        this.setState(() => {
            return ({
                data: new Date().toLocaleString()
            });
        })
    }

    componentDidMount() { 
        this.interval = setInterval(() => this.tick(), 1000);
    }

    componentWillUnmount() { 
        clearInterval(this.interval);
    }

    render() {
        return React.createElement(
            'h1',
            { className: 'orange' },
            `Hello World, Class - ${this.state.data}`
        );
    }
}

ReactDOM.render(
    React.createElement(Hello, {}, null),
    document.getElementById('app')
);
