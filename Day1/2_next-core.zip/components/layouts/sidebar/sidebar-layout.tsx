import Link from 'next/link';
import React from 'react';

const SidebarLayout = () => {
    return (
        <div className='container-fluid mt-3 mb-3'>
            <div className="text-center">
                <Link href="/">Home</Link>
                <span> | </span>
                <Link href="/about">About</Link>
                <span> | </span>
                <Link href="/contact">Contact</Link>
            </div>
        </div>
    );
};

export default SidebarLayout;