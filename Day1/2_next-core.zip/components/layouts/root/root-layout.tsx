import Link from 'next/link';
import React from 'react';

const RootLayout = ({ children }: { children: React.ReactNode }) => {
    return (
        <div className='container-fluid'>
            <div className="text-center">
                <Link href="/">Index</Link>
                <span> | </span>
                <Link href="/hooks">Hooks</Link>
            </div>
            {children}
        </div>
    );
};

export default RootLayout;