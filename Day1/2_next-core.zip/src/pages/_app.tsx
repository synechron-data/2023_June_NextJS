// import 'bootstrap/dist/css/bootstrap.css'
// import 'bootstrap-icons/font/bootstrap-icons.css'
// import '@/styles/globals.css'

// // Will NOT work and will cause errors - ReferenceError: document is not defined
// // import 'bootstrap';

// import type { AppProps } from 'next/app'

// export default function App({ Component, pageProps }: AppProps) {
//   return <Component {...pageProps} />
// }

// // --------------------------------------------

// import 'bootstrap/dist/css/bootstrap.css'
// import 'bootstrap-icons/font/bootstrap-icons.css'
// import '@/styles/globals.css'

// import type { AppProps } from 'next/app'
// import { useEffect } from 'react'

// export default function App({ Component, pageProps }: AppProps) {
//   useEffect(() => {
//     import('bootstrap');
//     import('lodash');
//   }, []);

//   return <Component {...pageProps} />
// }

// -------------------------------------------- Configure Root Layout

// import 'bootstrap/dist/css/bootstrap.css'
// import 'bootstrap-icons/font/bootstrap-icons.css'
// import '@/styles/globals.css'

// import type { AppProps } from 'next/app'
// import { useEffect } from 'react'
// import RootLayout from '../../components/layouts/root/root-layout'

// export default function App({ Component, pageProps }: AppProps) {
//   useEffect(() => {
//     import('bootstrap');
//     import('lodash');
//   }, []);

//   return (
//     <RootLayout>
//       <Component {...pageProps} />
//     </RootLayout>
//   )
// }

// -------------------------------------------- Per Page Layout

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-icons/font/bootstrap-icons.css'
import '@/styles/globals.css'

import type { AppProps } from 'next/app'
import { useEffect } from 'react'
import RootLayout from '../../components/layouts/root/root-layout'

export default function App({ Component, pageProps }: AppProps) {
  useEffect(() => {
    import('bootstrap');
    import('lodash');
  }, []);

  const getLayout = (Component as any).getLayout || ((page: any) => <RootLayout> {page} </RootLayout>);

  return getLayout(<Component {...pageProps} />)
}